#ifndef DEFAULTS_H
#define DEFAULTS_H

    #define BUZEER_ON 250
    #define BUZEER_OFF 0
    #define DEGREE_0 1
    #define DEGREE_90 3
    
#endif 
