#ifndef GOAL_H
#define GOAL_H

    #include "project.h"
    
    #include "defaults.h"
    #include "protocol.h"
    #include "i2c_goal.h"
    #include "sensors.h"
    #include "buttons.h"
    
#endif
    