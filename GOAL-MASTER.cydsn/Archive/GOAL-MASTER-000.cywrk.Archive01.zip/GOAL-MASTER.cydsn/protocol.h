#ifndef PROTOCOL_H
#define PROTOCOL_H
    
    void protocol_init(void);
    
#endif
    