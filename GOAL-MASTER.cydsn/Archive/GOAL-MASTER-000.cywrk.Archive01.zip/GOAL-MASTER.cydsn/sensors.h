#ifndef SENSORS_H
#define SENSORS_H
#include "goal.h"

    uint16 gas_sensor_signalization(); 
    void signalization_state(uint8 value);
    
#endif
    