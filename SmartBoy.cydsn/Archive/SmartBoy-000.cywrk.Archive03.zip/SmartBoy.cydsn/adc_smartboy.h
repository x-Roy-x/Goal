#ifndef ADC_BIPBOY_H
#define ADC_BIPBOY_H
#include "smartboy.h"
    
    void adc_init(void);
    
    uint16 adc_channel_value(uint8 channel); 
    
#endif
    