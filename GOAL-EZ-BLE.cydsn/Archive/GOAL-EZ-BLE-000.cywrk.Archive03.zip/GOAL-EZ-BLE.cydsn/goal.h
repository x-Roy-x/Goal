#ifndef GOAL_H
#define GOAL_H
    
    #include "project.h"
    
    #include "i2c_goal.h"
    #include "protocol.h"
    #include "ez_ble_goal.h"
    #include "ble_update.h"
    
#endif
    