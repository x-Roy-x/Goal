#ifndef BLE_UPDATE_H
#define BLE_UPDATE_H
#include "goal.h"
    
    void update_data_read(void);
    
/***************************************************************************************************************************/
    
    void update_data_write(CYBLE_GATTS_WRITE_CMD_REQ_PARAM_T *wrReqParamS);
    
#endif
    