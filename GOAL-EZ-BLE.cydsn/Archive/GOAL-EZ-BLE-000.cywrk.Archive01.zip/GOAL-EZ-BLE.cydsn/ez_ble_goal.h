#ifndef EZ_BLE_GOAL_H
#define EZ_BLE_GOAL_H
#include "goal.h"
    
    void BleCallBack(uint32 event, void* eventParam);
    
#endif
    